"""Number platform for HYXI Cloud device control power settings."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, NamedTuple

from homeassistant.components.number import NumberEntity, NumberMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfPower
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity import EntityCategory
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity
from homeassistant.helpers.update_coordinator import CoordinatorEntity
from hyxi_cloud_api import HyxiApiClient

from .const import (
    AVG_NIGHT_CONSUMPTION_MAX,
    AVG_NIGHT_CONSUMPTION_MIN,
    AVG_NIGHT_CONSUMPTION_STEP,
    CONF_EM_ENABLED,
    CONF_EM_INVERTER_SN,
    DOMAIN,
    EM_DEFAULTS,
    MANUFACTURER,
    detect_phase_type,
    get_raw_device_code,
    is_battery_control_enabled,
    is_control_capable_device_type,
    is_modbus_entry,
    mask_sn,
    normalize_device_type,
)

if TYPE_CHECKING:
    from .coordinator import HyxiDataUpdateCoordinator

_LOGGER = logging.getLogger(__name__)

_MAX_POWER_KEYS = {
    "charge": "maxChargePower",
    "discharge": "maxDischargePower",
}

PROTECTION_NUMBER_DEFS: list[dict[str, str | int]] = [
    {
        "key": "soc_min",
        "unit": "%",
        "min": 5,
        "max": 50,
        "default": 20,
        "icon": "mdi:battery-20",
    },
    {
        "key": "soc_max",
        "unit": "%",
        "min": 50,
        "max": 100,
        "default": 90,
        "icon": "mdi:battery-90",
    },
    {
        "key": "soc_min_hysteresis_pct",
        "unit": "%",
        "min": 0,
        "max": 10,
        "default": 2,
        "icon": "mdi:battery-sync",
    },
    {
        "key": "soc_max_hysteresis_pct",
        "unit": "%",
        "min": 0,
        "max": 10,
        "default": 2,
        "icon": "mdi:battery-sync-outline",
    },
]


class HyxiSettingNumberDef(NamedTuple):
    """Definition for a device-hardware setting number entity.

    Unlike HyxiProtectionNumber (pure HA-side automation thresholds, never
    touches the device) and HyxiPowerNumber (locally stored, sent only when
    a mode button is pressed), these write straight to the device's own
    settings register the moment the value changes -- there is no
    local-only state to hold in between.
    """

    key: str
    client_method: str
    unit: str
    min_val: float
    max_val: float
    step: float
    icon: str


# HaloSettings fields with an unambiguous numeric range and no interaction
# risk with an existing control method. dispatch_mode/active_power_setpoint
# is deliberately still not here: a second, untested dispatch path
# alongside the VPP block set_mode_* already drives, and neither the
# vendor document nor a public search turned up how the two interact on
# real hardware -- see docs/modbus-provenance.md. anti_starvation is
# boolean and lives in switch.py instead.
HALO_SETTING_NUMBER_DEFS: list[HyxiSettingNumberDef] = [
    HyxiSettingNumberDef(
        "feed_in_power_limit",
        "set_feed_in_power_limit",
        "W",
        0,
        15000,
        100,
        "mdi:transmission-tower-export",
    ),
    HyxiSettingNumberDef(
        "vpp_min_soc",
        "set_vpp_min_soc",
        "%",
        0,
        100,
        1,
        "mdi:battery-alert-variant-outline",
    ),
    HyxiSettingNumberDef(
        "force_charge_start_soc",
        "set_force_charge_start_soc",
        "%",
        0,
        100,
        1,
        "mdi:battery-charging-low",
    ),
    HyxiSettingNumberDef(
        "force_charge_stop_soc",
        "set_force_charge_stop_soc",
        "%",
        0,
        100,
        1,
        "mdi:battery-charging-high",
    ),
    HyxiSettingNumberDef(
        "off_grid_min_soc",
        "set_off_grid_min_soc",
        "%",
        0,
        100,
        1,
        "mdi:home-battery-outline",
    ),
    HyxiSettingNumberDef(
        "self_use_soc",
        "set_self_use_soc",
        "%",
        0,
        100,
        1,
        "mdi:home-battery",
    ),
    HyxiSettingNumberDef(
        "discharge_min_soc",
        "set_discharge_min_soc",
        "%",
        0,
        100,
        1,
        "mdi:battery-arrow-down-outline",
    ),
]

# Same idea for HybridSettings. power_command is deliberately not here --
# one of its three values restarts the inverter, which is a button.py
# concern (with a confirmation), not a number box. anti_starvation_protection
# is boolean and lives in switch.py instead.
HYBRID_SETTING_NUMBER_DEFS: list[HyxiSettingNumberDef] = [
    HyxiSettingNumberDef(
        "feed_in_power",
        "set_feed_in_power",
        "W",
        0,
        15000,
        100,
        "mdi:transmission-tower-export",
    ),
    HyxiSettingNumberDef(
        "max_charge_current",
        "set_max_charge_current",
        "A",
        0,
        200,
        0.1,
        "mdi:current-dc",
    ),
    HyxiSettingNumberDef(
        "self_use_soc",
        "set_self_use_soc",
        "%",
        0,
        100,
        1,
        "mdi:home-battery",
    ),
    HyxiSettingNumberDef(
        "backup_soc",
        "set_backup_soc",
        "%",
        0,
        100,
        1,
        "mdi:home-battery-outline",
    ),
    HyxiSettingNumberDef(
        "forced_charge_soc",
        "set_forced_charge_soc",
        "%",
        0,
        100,
        1,
        "mdi:battery-charging-low",
    ),
    HyxiSettingNumberDef(
        "feed_in_soc",
        "set_feed_in_soc",
        "%",
        0,
        100,
        1,
        "mdi:transmission-tower-export",
    ),
    HyxiSettingNumberDef(
        "off_grid_soc",
        "set_off_grid_soc",
        "%",
        0,
        100,
        1,
        "mdi:transmission-tower-off",
    ),
    HyxiSettingNumberDef(
        "max_discharge_current",
        "set_max_discharge_current",
        "A",
        0,
        200,
        0.1,
        "mdi:current-dc",
    ),
]


class EMNumberDef(NamedTuple):
    """Definition for an Energy Manager number entity."""

    key: str
    unit: str
    min_val: float
    max_val: float
    step: float
    icon: str


# EM-only: created only when Energy Manager is enabled in options
EM_NUMBER_DEFS: list[EMNumberDef] = [
    EMNumberDef("high_load_threshold", "W", 1000, 20000, 500, "mdi:flash-alert"),
    EMNumberDef("max_charge_power", "W", 500, 15000, 100, "mdi:lightning-bolt"),
    EMNumberDef(
        "max_discharge_power", "W", 500, 15000, 100, "mdi:lightning-bolt-outline"
    ),
    EMNumberDef(
        "min_solar_for_charge", "W", 200, 3000, 100, "mdi:solar-power-variant-outline"
    ),
    EMNumberDef("mode_switch_cooldown", "s", 10, 300, 5, "mdi:timer-outline"),
    EMNumberDef("power_change_threshold", "W", 10, 500, 10, "mdi:delta"),
    EMNumberDef("power_adjust_cooldown", "s", 5, 120, 5, "mdi:timer-sand"),
    EMNumberDef("night_buffer_pct", "%", 0, 20, 1, "mdi:shield-half-full"),
    EMNumberDef(
        "avg_night_consumption",
        "W",
        AVG_NIGHT_CONSUMPTION_MIN,
        AVG_NIGHT_CONSUMPTION_MAX,
        AVG_NIGHT_CONSUMPTION_STEP,
        "mdi:weather-night",
    ),
    EMNumberDef("charge_margin", "W", 0, 500, 25, "mdi:margin"),
    EMNumberDef(
        "charge_entry_threshold", "W", 100, 2000, 50, "mdi:solar-power-variant-outline"
    ),
    EMNumberDef("charge_reentry_delay", "s", 30, 600, 15, "mdi:timer-lock"),
    EMNumberDef("bottomout_cooldown", "s", 60, 900, 30, "mdi:timer-alert"),
    EMNumberDef("p1_smoothing_period", "s", 1, 300, 1, "mdi:chart-timeline-variant"),
    EMNumberDef("max_grid_export", "W", 0, 10000, 100, "mdi:transmission-tower-export"),
]


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up HYXI number entities for charge/discharge power settings."""
    coordinator = hass.data[DOMAIN][entry.entry_id]
    if not coordinator.data:
        return

    entities: list[NumberEntity] = []

    for sn, dev_data in coordinator.data.items():
        device_type = normalize_device_type(get_raw_device_code(dev_data))

        if device_type == "micro_inverter":
            # Microinverter power limit (controlId 3012)
            if is_battery_control_enabled(entry, coordinator):
                entities.append(HyxiMicroPowerLimit(coordinator, sn, dev_data))
            continue

        if not is_control_capable_device_type(entry, device_type):
            continue
        if not is_battery_control_enabled(entry, coordinator):
            continue

        if is_modbus_entry(entry):
            # Every Modbus mode button (set_mode_charge/discharge) reads its
            # wattage from these paired numbers -- see button.py's
            # _mode_buttons for why phase is irrelevant on this transport.
            entities.append(HyxiPowerNumber(coordinator, sn, dev_data, "charge"))
            entities.append(HyxiPowerNumber(coordinator, sn, dev_data, "discharge"))
            for definition in PROTECTION_NUMBER_DEFS:
                entities.append(
                    HyxiProtectionNumber(coordinator, sn, dev_data, definition)
                )
            # One device per Modbus entry (see client.py's async_read_all),
            # so device_type here reliably tells the two register maps
            # apart -- no need for a separate family lookup.
            setting_defs = (
                HALO_SETTING_NUMBER_DEFS
                if device_type == "micro_ess"
                else HYBRID_SETTING_NUMBER_DEFS
            )
            for setting_def in setting_defs:
                entities.append(
                    HyxiSettingNumber(coordinator, sn, dev_data, setting_def)
                )
            continue

        phase = detect_phase_type(dev_data)
        # Power numbers pair with mode control (1062-1065) — three-phase only.
        # Peak shaving (single-phase) uses full inverter power, no wattage setting.
        if phase == "three_phase":
            entities.append(HyxiPowerNumber(coordinator, sn, dev_data, "charge"))
            entities.append(HyxiPowerNumber(coordinator, sn, dev_data, "discharge"))

        # SOC protection numbers for both three-phase and single-phase
        if phase in ("three_phase", "single_phase"):
            for definition in PROTECTION_NUMBER_DEFS:
                entities.append(
                    HyxiProtectionNumber(coordinator, sn, dev_data, definition)
                )

    # EM-only numbers — only when Energy Manager is enabled for this inverter
    em_sn = entry.options.get(CONF_EM_INVERTER_SN)
    if entry.options.get(CONF_EM_ENABLED) and em_sn and em_sn in coordinator.data:
        em_dev_data = coordinator.data.get(em_sn, {})
        em_is_single_phase = detect_phase_type(em_dev_data) == "single_phase"
        for numdef in EM_NUMBER_DEFS:
            # max_grid_export only relevant for single-phase export limiting
            if numdef.key == "max_grid_export" and not em_is_single_phase:
                continue
            entities.append(EMParameterNumber(coordinator, em_sn, numdef))

    if entities:
        async_add_entities(entities)


class HyxiPowerNumber(
    CoordinatorEntity["HyxiDataUpdateCoordinator"], NumberEntity, RestoreEntity
):
    """Number entity for setting the wattage used by charge/discharge mode commands.

    This entity stores the desired power level locally. The value is sent to
    the inverter when the user presses the Charge or Discharge mode button.
    """

    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = UnitOfPower.WATT
    _attr_mode = NumberMode.BOX
    _attr_native_step = 1
    _attr_native_min_value = 1
    _attr_icon = "mdi:flash"

    def __init__(
        self,
        coordinator: HyxiDataUpdateCoordinator,
        sn: str,
        dev_data: dict,
        direction: str,
    ) -> None:
        """Initialize the power number entity."""
        super().__init__(coordinator)
        self._sn = sn
        self._direction = direction
        self._attr_unique_id = f"hyxi_{sn}_{direction}_power"
        self._attr_translation_key = f"{direction}_power"
        metrics = dev_data.get("metrics") or {}
        metric_key = _MAX_POWER_KEYS.get(direction, "")
        self._attr_native_max_value = int(_safe_int(metrics.get(metric_key), 10000))
        self._attr_native_value = 100
        self._attr_device_info = {
            "identifiers": {(DOMAIN, sn)},
            "name": dev_data.get("device_name") or f"Device {sn}",
            "manufacturer": MANUFACTURER,
            "model": dev_data.get("model"),
            "serial_number": sn,
        }

    async def async_added_to_hass(self) -> None:
        """Restore last known value on startup."""
        await super().async_added_to_hass()
        if (last_state := await self.async_get_last_state()) is not None:
            try:
                self._attr_native_value = int(float(last_state.state))
            except ValueError, TypeError:
                _LOGGER.debug(
                    "Could not restore %s from state %r",
                    self._attr_unique_id,
                    last_state.state,
                )

    async def async_set_native_value(self, value: float) -> None:
        """Set the power value."""
        _LOGGER.debug(
            "%s changed: %s -> %s", self._attr_unique_id, self._attr_native_value, value
        )
        self._attr_native_value = int(value)
        self.async_write_ha_state()


class HyxiSettingNumber(
    CoordinatorEntity["HyxiDataUpdateCoordinator"], NumberEntity, RestoreEntity
):
    """A device-hardware setting, written straight to its Modbus register
    on every change -- see HyxiSettingNumberDef's docstring for how this
    differs from the other number entities in this file.

    Starts at the device's own current value, read once at client setup
    (ModbusClient.async_read_settings) rather than on every regular poll --
    settings change rarely, so re-reading the whole block forever isn't
    worth the extra traffic, and every set_* method already keeps this
    value in sync with what HA itself writes. That one-time read means
    this entity does not notice a change made outside HA (the app, the
    cloud) after startup -- only its own writes and its startup snapshot.
    Falls back to the last value *this* integration wrote (HA's restored
    state), then to the field's minimum, if the device couldn't be read at
    startup at all. 0 is never written on its own -- only an explicit
    change by the user calls the client.
    """

    _attr_has_entity_name = True
    _attr_mode = NumberMode.BOX
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(
        self,
        coordinator: HyxiDataUpdateCoordinator,
        sn: str,
        dev_data: dict,
        definition: HyxiSettingNumberDef,
    ) -> None:
        """Initialize the setting number."""
        super().__init__(coordinator)
        self._sn = sn
        self._definition = definition
        self._attr_unique_id = f"hyxi_{sn}_{definition.key}"
        self._attr_translation_key = definition.key
        self._attr_native_unit_of_measurement = definition.unit
        self._attr_native_min_value = definition.min_val
        self._attr_native_max_value = definition.max_val
        self._attr_native_step = definition.step
        self._attr_icon = definition.icon
        self._attr_device_info = {
            "identifiers": {(DOMAIN, sn)},
            "name": dev_data.get("device_name") or f"Device {sn}",
            "manufacturer": MANUFACTURER,
            "model": dev_data.get("model"),
            "serial_number": sn,
        }

        live_value = (dev_data.get("metrics") or {}).get(definition.key)
        self._has_live_value = live_value is not None
        self._attr_native_value = (
            live_value if self._has_live_value else definition.min_val
        )

    async def async_added_to_hass(self) -> None:
        """Restore the last value written, if the device's own current
        value wasn't available at startup to show instead."""
        await super().async_added_to_hass()
        if self._has_live_value:
            return
        if (last_state := await self.async_get_last_state()) is not None:
            try:
                self._attr_native_value = float(last_state.state)
            except ValueError, TypeError:
                _LOGGER.debug(
                    "Could not restore %s from state %r",
                    self._attr_unique_id,
                    last_state.state,
                )

    async def async_set_native_value(self, value: float) -> None:
        """Write the new value straight to the device."""
        client = self.coordinator.client
        method = getattr(client, self._definition.client_method)
        _LOGGER.debug(
            "%s changed: %s -> %s", self._attr_unique_id, self._attr_native_value, value
        )
        try:
            await method(value)
            self._attr_native_value = value
            self.async_write_ha_state()
        except HyxiApiClient.ControlError as err:
            _LOGGER.error(
                "Failed to set %s to %s for %s: %s",
                self._definition.key,
                value,
                mask_sn(self._sn),
                err,
            )
            raise


class HyxiMicroPowerLimit(
    CoordinatorEntity["HyxiDataUpdateCoordinator"], NumberEntity, RestoreEntity
):
    """Number entity for microinverter power limit (controlId 3012).

    Sets the maximum power output as a percentage of rated power.
    The value is sent to the inverter immediately on change.
    """

    _attr_has_entity_name = True
    _attr_translation_key = "micro_power_limit"
    _attr_native_unit_of_measurement = "%"
    _attr_mode = NumberMode.SLIDER
    _attr_native_step = 1.0
    _attr_native_min_value = 0.0
    _attr_native_max_value = 100.0
    _attr_native_value = 100.0
    _attr_icon = "mdi:speedometer"

    def __init__(
        self, coordinator: HyxiDataUpdateCoordinator, sn: str, dev_data: dict
    ) -> None:
        """Initialize the micro power limit entity."""
        super().__init__(coordinator)
        self._sn = sn
        self._attr_unique_id = f"hyxi_{sn}_micro_power_limit"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, sn)},
            "name": dev_data.get("device_name") or f"Device {sn}",
            "manufacturer": MANUFACTURER,
            "model": dev_data.get("model"),
            "serial_number": sn,
        }

    async def async_added_to_hass(self) -> None:
        """Restore last known value on startup."""
        await super().async_added_to_hass()
        if (last_state := await self.async_get_last_state()) is not None:
            try:
                self._attr_native_value = float(last_state.state)
            except ValueError, TypeError:
                _LOGGER.debug(
                    "Could not restore %s from state %r",
                    self._attr_unique_id,
                    last_state.state,
                )

    async def async_set_native_value(self, value: float) -> None:
        """Set the power limit and send to inverter."""
        client = self.coordinator.client
        _LOGGER.debug(
            "Setting micro power limit to %d%% for %s", int(value), mask_sn(self._sn)
        )
        try:
            await client.set_micro_power_limit(self._sn, int(value))
            self._attr_native_value = value
            self.async_write_ha_state()
        except HyxiApiClient.ControlError as err:
            _LOGGER.error(
                "Failed to set power limit to %d%% for %s: %s",
                int(value),
                mask_sn(self._sn),
                err,
            )
            raise


def _safe_int(val, default: int) -> int:
    """Safely convert a value to int with a fallback default."""
    if val is None:
        return default
    try:
        result = int(float(val))
        return result if result > 0 else default
    except ValueError, TypeError:
        return default


class HyxiProtectionNumber(
    CoordinatorEntity["HyxiDataUpdateCoordinator"], NumberEntity, RestoreEntity
):
    """Locally stored number for battery protection thresholds."""

    _attr_has_entity_name = True
    _attr_mode = NumberMode.BOX
    _attr_native_step = 1
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(
        self,
        coordinator: HyxiDataUpdateCoordinator,
        sn: str,
        dev_data: dict,
        definition: dict[str, str | int],
    ) -> None:
        """Initialize the protection number."""
        super().__init__(coordinator)
        self._sn = sn
        key = str(definition["key"])
        self._attr_unique_id = f"hyxi_{sn}_{key}"
        self._attr_translation_key = key
        self._attr_native_unit_of_measurement = str(definition["unit"])
        self._attr_native_min_value = int(definition["min"])
        self._attr_native_max_value = int(definition["max"])
        self._attr_native_value = int(definition["default"])
        self._attr_icon = str(definition["icon"])
        self._attr_device_info = {
            "identifiers": {(DOMAIN, sn)},
            "name": dev_data.get("device_name") or f"Device {sn}",
            "manufacturer": MANUFACTURER,
            "model": dev_data.get("model"),
            "serial_number": sn,
        }

    async def async_added_to_hass(self) -> None:
        """Restore the last configured value."""
        await super().async_added_to_hass()
        if (last_state := await self.async_get_last_state()) is not None:
            try:
                self._attr_native_value = int(float(last_state.state))
            except ValueError, TypeError:
                _LOGGER.debug(
                    "Could not restore protection number hyxi_%s_%s from state %s",
                    mask_sn(self._sn),
                    self._attr_translation_key,
                    last_state.state,
                )

    async def async_set_native_value(self, value: float) -> None:
        """Set the protection threshold value."""
        _LOGGER.debug(
            "%s changed: %s -> %s", self._attr_unique_id, self._attr_native_value, value
        )
        self._attr_native_value = int(value)
        self.async_write_ha_state()
        if (
            controller := getattr(self.coordinator, "protection_controllers", {}).get(
                self._sn
            )
        ) is not None:
            self.hass.async_create_task(controller.async_evaluate())


class EMParameterNumber(NumberEntity, RestoreEntity):
    """Number entity for an Energy Manager parameter.

    Stores a tunable value locally (RestoreEntity). The engine reads it
    each tick via _get_param(), and for a couple of parameters (e.g.
    avg_night_consumption) writes an adaptive value back via
    engine._set_param(), which sets the state machine value directly
    rather than going through this entity's own _attr_native_value.

    _attr_should_poll must stay False: this entity has nothing to poll (no
    device, no coordinator), but the base Entity default is True. Left at
    the default, Home Assistant's per-platform scan-interval timer would
    periodically call async_update_ha_state(force_refresh=True) on it,
    which re-derives state from the (stale, in-memory) _attr_native_value
    and silently overwrites engine._set_param()'s direct write within one
    poll cycle -- confirmed by reproducing it against a real EntityPlatform
    in a throwaway test before this fix.
    """

    _attr_has_entity_name = True
    _attr_mode = NumberMode.BOX
    _attr_entity_category = EntityCategory.CONFIG
    _attr_should_poll = False

    def __init__(
        self,
        coordinator: HyxiDataUpdateCoordinator,
        sn: str,
        numdef: EMNumberDef,
    ) -> None:
        """Initialize the EM parameter number entity."""
        self._sn = sn
        self._attr_unique_id = f"hyxi_{sn}_em_{numdef.key}"
        self._attr_translation_key = f"em_{numdef.key}"
        self._attr_native_unit_of_measurement = numdef.unit
        self._attr_native_min_value = numdef.min_val
        self._attr_native_max_value = numdef.max_val
        self._attr_native_step = numdef.step
        self._attr_icon = numdef.icon

        self._attr_native_value = float(EM_DEFAULTS.get(numdef.key, 0))
        self._attr_device_info = {
            "identifiers": {(DOMAIN, f"{sn}_energy_manager")},
        }

    async def async_added_to_hass(self) -> None:
        """Restore last known value on startup."""
        await super().async_added_to_hass()
        if (last_state := await self.async_get_last_state()) is not None:
            try:
                self._attr_native_value = float(last_state.state)
            except ValueError, TypeError:
                _LOGGER.debug(
                    "Could not restore %s from state %r",
                    self._attr_unique_id,
                    last_state.state,
                )

    async def async_set_native_value(self, value: float) -> None:
        """Set the parameter value."""
        _LOGGER.debug(
            "%s changed: %s -> %s", self._attr_unique_id, self._attr_native_value, value
        )
        self._attr_native_value = value
        self.async_write_ha_state()

    @callback
    def set_computed_value(self, value: float) -> None:
        """Update the value from an engine-computed adaptive parameter.

        Used by EnergyManagerEngine._set_param() for parameters the engine
        tunes itself (e.g. the hourly avg_night_consumption EMA), as
        opposed to async_set_native_value() which is for direct user edits
        via the UI. Keeps this entity's own _attr_native_value in sync
        with the write, so a manually forced update (which bypasses
        should_poll) can't republish a stale value.
        """
        self._attr_native_value = value
        self.async_write_ha_state()
