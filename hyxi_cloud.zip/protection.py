"""Minimal battery protection for HYXI inverter mode controls."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

from homeassistant.core import CALLBACK_TYPE, HomeAssistant, callback
from homeassistant.helpers import entity_registry as er

from .const import DOMAIN, detect_phase_type, is_modbus_entry, mask_sn

if TYPE_CHECKING:
    from .coordinator import HyxiDataUpdateCoordinator

_LOGGER = logging.getLogger(__name__)

DEFAULT_SOC_MIN = 20
DEFAULT_SOC_MAX = 90
DEFAULT_SOC_MIN_HYSTERESIS = 2
DEFAULT_SOC_MAX_HYSTERESIS = 2
MODE_SWITCH_COOLDOWN = 60


class HyxiBatteryProtectionController:
    """Protect battery SOC limits for supported HYXI manual controls."""

    def __init__(
        self,
        hass: HomeAssistant,
        coordinator: HyxiDataUpdateCoordinator,
        sn: str,
    ) -> None:
        """Initialize the battery protection controller."""
        self._hass = hass
        self._coordinator = coordinator
        self._sn = sn
        self._last_sent_mode: str | None = None
        self._low_soc_hold = False
        self._high_soc_hold = False
        self._last_mode_switch = -999999.0
        self._unsub_listener: CALLBACK_TYPE | None = None
        self._eval_task: asyncio.Task | None = None

    @property
    def last_sent_mode(self) -> str | None:
        """Return the last tracked mode command."""
        return self._last_sent_mode

    async def async_start(self) -> None:
        """Start listening for coordinator updates."""
        if self._unsub_listener is not None:
            return

        _LOGGER.debug(
            "Protection %s: battery protection controller starting", mask_sn(self._sn)
        )

        # Proactively restore the last sent mode from HASS state registry if it exists
        entity_id = f"sensor.hyxi_{self._sn}_last_sent_mode"
        if (state := self._hass.states.get(entity_id)) is not None:
            mode = state.state
            if mode not in ("unknown", "unavailable", ""):
                self._last_sent_mode = mode
                self._last_mode_switch = time.monotonic()
                _LOGGER.debug(
                    "Proactively restored battery protection mode %s from HASS state for %s",
                    mode,
                    mask_sn(self._sn),
                )

        self._unsub_listener = self._coordinator.async_add_listener(
            self._handle_coordinator_update
        )
        await self.async_evaluate()

    async def async_stop(self) -> None:
        """Stop listening for coordinator updates."""
        if self._unsub_listener is not None:
            self._unsub_listener()
            self._unsub_listener = None
            _LOGGER.debug(
                "Protection %s: battery protection controller stopping",
                mask_sn(self._sn),
            )
        if self._eval_task is not None and not self._eval_task.done():
            self._eval_task.cancel()
            self._eval_task = None

    def note_manual_mode(self, mode: str) -> None:
        """Track a user-triggered mode command."""
        self._last_sent_mode = mode

    def restore_last_sent_mode(self, mode: str) -> None:
        """Restore the last tracked mode from restored state."""
        if mode not in {
            "idle",
            "charge",
            "discharge",
            "self_consume",
            "close",
            "stop",
            "hold",
        }:
            return

        self._last_sent_mode = mode
        self._last_mode_switch = time.monotonic()

    def should_block_manual_discharge(self) -> bool:
        """Return True when manual discharge should be blocked by SOC protection."""
        soc = self._get_soc()
        if soc is None:
            return False
        soc_min = self._get_param("soc_min", DEFAULT_SOC_MIN)
        return soc <= soc_min

    def should_block_manual_charge(self) -> bool:
        """Return True when manual charge should be blocked by SOC protection."""
        soc = self._get_soc()
        if soc is None:
            return False

        soc_max = self._get_param("soc_max", DEFAULT_SOC_MAX)
        soc_max_resume = max(
            0,
            soc_max
            - self._get_param(
                "soc_max_hysteresis_pct",
                DEFAULT_SOC_MAX_HYSTERESIS,
            ),
        )

        if soc >= soc_max:
            return True
        return self._high_soc_hold and soc > soc_max_resume

    @callback
    def _handle_coordinator_update(self) -> None:
        """Evaluate protection rules after new coordinator data arrives."""
        if self._eval_task is not None and not self._eval_task.done():
            self._eval_task.cancel()
        self._eval_task = self._hass.async_create_task(self.async_evaluate())

    async def async_evaluate(self) -> None:
        """Evaluate the current SOC and enforce protection limits."""
        dev_data = (self._coordinator.data or {}).get(self._sn)
        if not dev_data:
            _LOGGER.debug(
                "Protection %s: skipping evaluation, no coordinator data yet",
                mask_sn(self._sn),
            )
            return

        metrics = dev_data.get("metrics") or {}
        soc = self._metric_float(metrics.get("batSoc"))
        if soc is None:
            _LOGGER.debug(
                "Protection %s: skipping evaluation, batSoc metric missing",
                mask_sn(self._sn),
            )
            return

        soc_min = self._get_param("soc_min", DEFAULT_SOC_MIN)
        soc_max = self._get_param("soc_max", DEFAULT_SOC_MAX)
        mode_control = self._uses_mode_control()
        soc_min_resume = min(
            soc_max,
            soc_min
            + self._get_param(
                "soc_min_hysteresis_pct",
                DEFAULT_SOC_MIN_HYSTERESIS,
            ),
        )
        soc_max_resume = max(
            soc_min,
            soc_max
            - self._get_param(
                "soc_max_hysteresis_pct",
                DEFAULT_SOC_MAX_HYSTERESIS,
            ),
        )

        _LOGGER.debug(
            "Protection %s: soc=%.1f soc_min=%.1f soc_max=%.1f low_hold=%s high_hold=%s last_mode=%s",
            mask_sn(self._sn),
            soc,
            soc_min,
            soc_max,
            self._low_soc_hold,
            self._high_soc_hold,
            self._last_sent_mode,
        )

        if soc <= soc_min:
            if not self._low_soc_hold:
                _LOGGER.debug(
                    "Protection %s: entering low-SOC hold (soc=%.1f <= soc_min=%.1f)",
                    mask_sn(self._sn),
                    soc,
                    soc_min,
                )
            self._low_soc_hold = True
            if self._last_sent_mode != "charge":
                await self._ensure_mode("idle" if mode_control else "hold")
            return

        if self._low_soc_hold:
            if soc < soc_min_resume:
                if self._last_sent_mode != "charge":
                    await self._ensure_mode("idle" if mode_control else "hold")
                return
            _LOGGER.debug(
                "Protection %s: exiting low-SOC hold (soc=%.1f >= resume=%.1f)",
                mask_sn(self._sn),
                soc,
                soc_min_resume,
            )
            self._low_soc_hold = False

        if soc >= soc_max:
            if not self._high_soc_hold:
                _LOGGER.debug(
                    "Protection %s: entering high-SOC hold (soc=%.1f >= soc_max=%.1f)",
                    mask_sn(self._sn),
                    soc,
                    soc_max,
                )
            self._high_soc_hold = True
            if mode_control:
                if self._last_sent_mode not in ("discharge", "idle", "self_consume"):
                    await self._ensure_mode("idle")
            elif self._last_sent_mode not in ("discharge", "hold"):
                await self._ensure_mode("hold")
            return

        if self._high_soc_hold:
            if soc > soc_max_resume:
                if mode_control:
                    if self._last_sent_mode not in (
                        "discharge",
                        "idle",
                        "self_consume",
                    ):
                        await self._ensure_mode("idle")
                elif self._last_sent_mode not in ("discharge", "hold"):
                    await self._ensure_mode("hold")
                return
            _LOGGER.debug(
                "Protection %s: exiting high-SOC hold (soc=%.1f <= resume=%.1f)",
                mask_sn(self._sn),
                soc,
                soc_max_resume,
            )
            self._high_soc_hold = False

    async def _ensure_mode(self, mode: str) -> None:
        """Send a mode command if cooldown allows it and mode changed."""
        if self._last_sent_mode == mode:
            return
        remaining = MODE_SWITCH_COOLDOWN - (time.monotonic() - self._last_mode_switch)
        if remaining > 0:
            _LOGGER.debug(
                "Protection %s: mode switch to %s suppressed, cooldown %.0fs remaining",
                mask_sn(self._sn),
                mode,
                remaining,
            )
            return

        await self._send_control(mode)

        self._last_sent_mode = mode
        self._last_mode_switch = time.monotonic()
        await self._coordinator.async_request_refresh()

    async def _send_control(self, mode: str) -> None:
        """Send the requested control using the correct transport-specific API."""
        client = self._coordinator.client

        if is_modbus_entry(self._coordinator.entry):
            mode_control = True
        else:
            # Preserved from before this method understood transports: an
            # entry only reaches here via a real controller instance, which
            # __init__.py never creates for a cloud device whose phase came
            # back "unknown" -- so this is a defensive check for a phase
            # that changed after startup, not a case expected in practice.
            phase = self._phase_type()
            if phase not in ("three_phase", "single_phase"):
                raise ValueError(f"Unsupported phase type for protection: {phase}")
            mode_control = phase == "three_phase"

        _LOGGER.debug(
            "Protection %s: sending mode=%s mode_control=%s",
            mask_sn(self._sn),
            mode,
            mode_control,
        )

        if mode_control:
            if mode == "idle":
                await client.set_mode_idle(self._sn)
            elif mode == "charge":
                await client.set_mode_charge(self._sn, self._get_power_value("charge"))
            elif mode == "discharge":
                await client.set_mode_discharge(
                    self._sn, self._get_power_value("discharge")
                )
            elif mode == "self_consume":
                await client.set_mode_self_consume(self._sn)
            else:
                raise ValueError(f"Unsupported three-phase protection mode: {mode}")
            return

        if mode not in {"close", "charge", "discharge", "stop", "hold"}:
            raise ValueError(f"Unsupported single-phase protection mode: {mode}")
        await client.set_peak_shaving(self._sn, mode)

    def _get_param(self, key: str, default: int) -> int:
        """Read a protection number value from the entity registry."""
        unique_id = f"hyxi_{self._sn}_{key}"
        registry = er.async_get(self._hass)
        entity_id = registry.async_get_entity_id("number", DOMAIN, unique_id)
        if entity_id is None:
            return default

        state = self._hass.states.get(entity_id)
        if state is None or state.state in ("unknown", "unavailable", ""):
            return default

        try:
            return int(float(state.state))
        except ValueError, TypeError:
            _LOGGER.debug(
                "Protection %s: could not parse %s state %r, using default %s",
                mask_sn(self._sn),
                entity_id,
                state.state,
                default,
            )
            return default

    def _get_power_value(self, direction: str) -> int:
        """Read the stored charge or discharge power value."""
        unique_id = f"hyxi_{self._sn}_{direction}_power"
        registry = er.async_get(self._hass)
        entity_id = registry.async_get_entity_id("number", DOMAIN, unique_id)
        if entity_id is None:
            return 100

        state = self._hass.states.get(entity_id)
        if state is None or state.state in ("unknown", "unavailable", ""):
            return 100

        try:
            watts = int(float(state.state))
            return max(watts, 1)
        except ValueError, TypeError:
            _LOGGER.debug(
                "Protection %s: could not parse %s state %r, using default 100",
                mask_sn(self._sn),
                entity_id,
                state.state,
            )
            return 100

    def _get_soc(self) -> float | None:
        """Read the current battery SOC."""
        dev_data = (self._coordinator.data or {}).get(self._sn)
        if not dev_data:
            return None
        metrics = dev_data.get("metrics") or {}
        return self._metric_float(metrics.get("batSoc"))

    def _phase_type(self) -> str:
        """Return the detected phase type for this device."""
        dev_data = (self._coordinator.data or {}).get(self._sn) or {}
        return detect_phase_type(dev_data)

    def _uses_mode_control(self) -> bool:
        """Whether this device should be driven through the mode surface
        (idle/charge/discharge/self-use) rather than the cloud's separate
        peak-shaving surface (hold/charge/discharge/stop/close).

        Over the cloud this is decided by electrical phase count -- HYXI's
        controlId 1062-1065 (mode) applies to three-phase hardware,
        controlId 1021 (peak shaving) to single-phase. Local Modbus has no
        such split: both register maps this integration supports over
        Modbus expose the same 4-state mode surface regardless of phase
        count, and neither has a confirmed local equivalent of peak
        shaving's extra states -- so a Modbus device always uses mode
        control, the same decision button.py/number.py make. This must
        stay the one place that decision is made and read by both the SOC
        decision logic (which mode name to pick) and _send_control (which
        client method to call) -- if the two ever disagreed, _send_control
        would receive a mode name from the wrong vocabulary entirely (e.g.
        "hold", which set_mode_idle's surface has no meaning for).
        """
        if is_modbus_entry(self._coordinator.entry):
            return True
        return self._phase_type() == "three_phase"

    @staticmethod
    def _metric_float(value) -> float | None:
        """Parse a coordinator metric as float."""
        if value is None:
            return None
        try:
            return float(value)
        except ValueError, TypeError:
            return None
